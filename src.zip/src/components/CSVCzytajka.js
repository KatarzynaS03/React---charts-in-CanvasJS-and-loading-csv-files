import React, {Component} from "react";
import CSVReader from "react-csv-reader";
import "./style.css";
import TestPlot3 from "./TestPlot3";
import CanvasJSReact from "../lib/canvasjs.react";
let CanvasJSChart = CanvasJSReact.CanvasJSChart;

class CSVCzytajka extends Component{
    state = {waikato:[], auckland: [], wellington: []}
    handleForce = (data) => {
        const emiss=[]
        const emiss1=[]
        const emiss2=[]
        data.forEach((row) => {

            if (row.region === "Waikato"){
                emiss.push({x: row.year, y: row.data_val})
            }
            if (row.region === "Auckland")
                emiss1.push({x: row.year, y: row.data_val})
            if (row.region === "Wellington")
                emiss2.push({x: row.year, y: row.data_val})
        });
        this.setState({waikato: emiss})
        this.setState({auckland: emiss1})
        this.setState({wellington:emiss2})
    }

    papaparseOptions = {
        header: true,
        dynamicTyping: true,
        skipEmptyLines: true,
        transformHeader: header => header.toLowerCase().replace(/\W/g, "")
    };
    hide(){
        return(
            <div>
                <TestPlot3 data = {this.state}></TestPlot3>
            </div>

        )
    }
    render () {

        return (
            <div className="container">
                <CSVReader
                    cssClass="react-csv-input"
                    label="Select CSV with secret anti-vaccine statistics"
                    onFileLoaded={this.handleForce}
                    parserOptions={this.papaparseOptions}
                />

                    <TestPlot3 data = {this.state}></TestPlot3>

            </div>
        );
    }
}


export default CSVCzytajka;