import React, {Component} from 'react';
import CanvasJSReact from '../lib/canvasjs.react';
import {bottomNavigationActionClasses, Button, Grid} from "@mui/material";
let CanvasJSChart = CanvasJSReact.CanvasJSChart;
class TestPlot3 extends Component {

    s = "Ukryj Waikato";
    s1 = "Ukryj Auckland"
    s2 = "Ukryj Wellington"

    hide(){
        if(this.state.waikato_visible === true){
            this.setState({waikato_visible : false})
            this.s = "Pokaż Waikato"
        }
        if(this.state.waikato_visible === false){
            this.setState({waikato_visible : true})
            this.s = "Ukryj Waikato"
        }

    }
    hide1(){
        if(this.state.auckland_visble === true){
            this.setState({auckland_visble : false})
            this.s1 = "Pokaż Auckland"
        }
        if(this.state.auckland_visble === false){
            this.setState({auckland_visble : true})
            this.s1 = "Ukryj Auckland"
        }

    }
    hide2(){
        if(this.state.wellington_visible === true){
            this.setState({wellington_visible : false})
            this.s2 = "Pokaż Wellington"
        }
        if(this.state.wellington_visible === false){
            this.setState({wellington_visible : true})
            this.s2 = "Ukryj Wellington"
        }

    }

    hideChart(){
        if(this.state.wellington_visible && this.state.waikato_visible && this.state.auckland_visble === true){
            this.setState({chart_visible : false})
        }
        if(this.state.wellington_visible && this.state.waikato_visible && this.state.auckland_visble === false){
            this.setState({chart_visible : true})
        }

    }
    state = {waikato_visible : true, auckland_visble : true, wellington_visible : true, chart_visible: true}
    render() {
        let chart = null;

        const options = {
            visible: false,
            legend:{
                fontSize: 17,
                fontFamily: "tamoha",
                fontColor: "Sienna"
            },
            zoomEnabled: true,
            width: 700,

            title: {
                text: "Greenhouse gas emissions by regions"
            },
            axisX: {
                valueFormatString:"####",
                labelAngle: -45,
                title: "Year",
                interlacedColor: "#F0F8FF"
            },
            axisY: {
                interlacedColor: "#F0F8FF" ,
                valueFormatString: "####.##",
                title: "Emission [kt]"
            },
            data: [{
                visible: this.state.waikato_visible,
                type: "line",
                dataPoints: this.props.data.waikato,
                legendText: "Waikato",
                showInLegend: this.state.waikato_visible,
            },
                {
                    visible: this.state.auckland_visble,
                    type: "line",
                    dataPoints: this.props.data.auckland,
                    legendText: "Auckland",
                    showInLegend: this.state.auckland_visble,
                },
                {
                    visible: this.state.wellington_visible,
                    type: "line",
                    dataPoints: this.props.data.wellington,
                    legendText: "Wellington",
                    showInLegend: this.state.wellington_visible,
                }
            ]
        }
        return (

            <div>
                <div>
                    <Button variant="contained" onClick={() => this.hide()}>{this.s}</Button>{' '}
                    <Button variant="contained" color="secondary" onClick={() => this.hide1()}>{this.s1}</Button>{' '}
                    <Button variant="contained" color="warning" onClick={() => this.hide2()}>{this.s2}</Button>{' '}
                    <br/>
                </div>
                <br/><br/>
                <Grid marginLeft={25}>
                <CanvasJSChart canvas="auto" options={options}/></Grid>
            </div>
        );
    }
}

export default TestPlot3;