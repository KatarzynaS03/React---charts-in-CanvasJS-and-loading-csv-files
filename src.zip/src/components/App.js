import React, {Component} from 'react';
import CSVCzytajka from "./CSVCzytajka";

class App extends Component {

    render() {

        return (
            <div className="App">
                <CSVCzytajka></CSVCzytajka>
            </div>
        );
    }
constructor(props) {
        super(props);
        this.state = {
            list: CSVCzytajka
        };
    }

}

export default App;

